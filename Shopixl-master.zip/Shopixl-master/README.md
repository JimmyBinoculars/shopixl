![Shopixl Logo](https://s2.postimg.org/ems4zkzah/logotxt.png)
### Open-source, self-hosted, Buycraft alternative.

# What?
WIP (Webstore for Minecraft Servers.)

# Why?
WIP (Because Buycraft is expensive and not everybody can afford it.)

# How to install?
* Download latest release
* Upload to your Web-Server and extract
* Open your-site-url.tld/path/to/install and follow the guide through the installation proccess

# Credits
WIP

# License
Shopixl is licensed under the [MIT License](https://github.com/Skayo/Shopixl/blob/master/LICENSE.md "Go to License")
